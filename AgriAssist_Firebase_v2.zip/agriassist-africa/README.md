# AgriAssist Africa 🌿
**La plateforme intelligente de l'agriculture africaine**

## 📍 Coordonnées
- **Adresse :** Bafoussam, Cameroun
- **Email :** AgriAssist@africa.com
- **Téléphone :** +237 697 380 148

---

## 🚀 Installation rapide

```bash
# 1. Extraire le projet
unzip AgriAssist_Africa_Deploy.zip && cd agriassist-africa

# 2. Créer l'environnement virtuel
python3 -m venv venv && source venv/bin/activate

# 3. Installer les dépendances
pip install -r requirements.txt

# 4. Configurer l'environnement
cp .env.example .env  # Modifier selon vos besoins

# 5. Lancer l'application
python app.py
```

## 🌐 Accès
- **Application :** http://localhost:5000
- **Dashboard Utilisateur :** http://localhost:5000/dashboard  (après connexion)
- **Panel Admin :** http://localhost:5000/admin  (réservé aux admins)

---

## 🔐 IDENTIFIANTS ADMINISTRATEUR

> ⚠️ **CONFIDENTIEL — À CHANGER EN PRODUCTION**

### Admin Principal
| Champ | Valeur |
|-------|--------|
| **ID Admin** | `ADMIN001` |
| **Mot de passe** | `AgriAdmin@2026!` |
| **Rôle** | Administrateur Principal |
| **Téléphone** | +237 697 380 148 |

### Super Administrateur
| Champ | Valeur |
|-------|--------|
| **ID Admin** | `ADMIN002` |
| **Mot de passe** | `SuperAdmin#2026` |
| **Rôle** | Super Administrateur |

### Comment se connecter en Admin
1. Aller sur http://localhost:5000/login
2. Saisir l'ID Admin (ex: `ADMIN001`)
3. Saisir le mot de passe correspondant
4. Vous serez redirigé vers le dashboard utilisateur
5. Accéder à http://localhost:5000/admin pour le panel administrateur

### Droits Administrateur (Panel `/admin`)
- ✅ Vue d'ensemble · statistiques globales
- ✅ Gestion des utilisateurs (activer/suspendre)
- ✅ Contrôle des accès par module
- ✅ Flux financiers · transactions · wallet
- ✅ Gestion des abonnements et assurances
- ✅ CRM professionnel
- ✅ Système de ticketing
- ✅ Campagnes SMS
- ✅ Export rapports PDF

---

## 📦 Modules Inclus
| Module | Accès | Description |
|--------|-------|-------------|
| Radar des Maladies | Gratuit | IA Vision · 98% précision |
| Champ & Satellite | Bientôt | NDVI · GPS · CSV |
| Assurance Paramétrique | Premium | Sécheresse · NDVI · Pluie |
| FinPro Documents | Premium | Business Plan · Pitch Deck |
| Marketplace | 10 000 FCFA/mois | Négoce · Coach IA |
| ERP Agricole | Premium | Gestion · Comptabilité |
| Wallet | Premium | Paiements · Indemnisations |
| Plan NPK | Gratuit | Calcul engrais |
| Irrigation IA | Gratuit | Calendrier arrosage |
| Hub Marché | Gratuit | Prix FCFA temps réel |
| Alertes | Gratuit | Rappels & agenda |
| Apprentissage | Gratuit | Tutoriels agricoles |

## 🔧 Stack Technique
- **Backend :** Python 3.10+ / Flask
- **Database :** SQLite (dev) / PostgreSQL (prod)
- **Maps :** Leaflet.js + OpenStreetMap
- **IA :** TensorFlow / MobileNetV2
- **PWA :** Service Worker + Web App Manifest
- **UI :** HTML/CSS/JS pur (responsive mobile + desktop)

© 2026 AgriAssist Africa · Bafoussam, Cameroun
