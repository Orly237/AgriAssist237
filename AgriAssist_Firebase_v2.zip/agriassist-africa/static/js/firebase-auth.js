// ═══════════════════════════════════════════════════════════
//  AgriAssist Africa – Firebase Auth + Firestore API
//  Toutes les opérations auth et données sont ici
// ═══════════════════════════════════════════════════════════

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

import {
  doc, setDoc, getDoc, updateDoc,
  collection, addDoc, getDocs,
  query, where, orderBy, limit,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

import { auth, db } from "/static/js/firebase-config.js";

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────

/** Génère ID agriculteur  ex: FE69938 */
function makeFarmerId(phone) {
  const digits = phone.replace(/\D/g, '').slice(-4).padStart(4, '0');
  const rand   = String(Math.floor(Math.random() * 90 + 10));
  return `FE${digits}${rand}`;
}

/** Email synthétique depuis le téléphone */
function phoneToEmail(phone) {
  return `${phone.replace(/\D/g, '')}@agriassist.app`;
}

/** Résoudre "identifier" → email Firebase */
async function resolveEmail(identifier) {
  identifier = identifier.trim();

  // Email direct
  if (identifier.includes('@') && !identifier.endsWith('@agriassist.app')) {
    return identifier;
  }

  // FarmerId (FExxxx ou ADMIN00x)
  if (/^(FE|ADMIN)/i.test(identifier)) {
    const snap = await getDoc(doc(db, 'farmerIndex', identifier.toUpperCase()));
    if (!snap.exists()) throw new Error(`ID Agriculteur introuvable : ${identifier}`);
    return snap.data().email;
  }

  // Téléphone → email synthétique
  return phoneToEmail(identifier);
}

// ─────────────────────────────────────────────
//  INSCRIPTION
// ─────────────────────────────────────────────

export async function fbRegister({ name, phone, email, password, language, crops, plan }) {
  const userEmail  = email?.trim() || phoneToEmail(phone);
  const farmerId   = makeFarmerId(phone);
  const role       = 'user';

  // 1. Créer le compte Firebase Auth
  const cred = await createUserWithEmailAndPassword(auth, userEmail, password);
  await updateProfile(cred.user, { displayName: name });

  const uid = cred.user.uid;

  // 2. Profil Firestore
  const profile = {
    uid, farmerId, name,
    phone: phone.trim(),
    email: userEmail,
    language: language || 'fr',
    crops: crops || '',
    role, plan: plan || 'freemium',
    walletBalance: 0,
    active: true,
    createdAt: serverTimestamp(),
    lastLogin: serverTimestamp()
  };
  await setDoc(doc(db, 'users', uid), profile);

  // 3. Index inversé farmerId → uid / email
  await setDoc(doc(db, 'farmerIndex', farmerId), {
    uid, email: userEmail, phone: phone.trim(), name, role
  });

  return { uid, farmerId, name, role, email: userEmail };
}

// ─────────────────────────────────────────────
//  CONNEXION
// ─────────────────────────────────────────────

export async function fbLogin({ identifier, password }) {
  const email = await resolveEmail(identifier);
  const cred  = await signInWithEmailAndPassword(auth, email, password);
  const uid   = cred.user.uid;

  const snap = await getDoc(doc(db, 'users', uid));
  if (!snap.exists()) throw new Error('Profil introuvable dans Firestore.');

  await updateDoc(doc(db, 'users', uid), { lastLogin: serverTimestamp() });

  const data = snap.data();

  // Stocker en sessionStorage pour usage local
  sessionStorage.setItem('agri_uid',       uid);
  sessionStorage.setItem('agri_farmer_id', data.farmerId);
  sessionStorage.setItem('agri_name',      data.name);
  sessionStorage.setItem('agri_role',      data.role);
  sessionStorage.setItem('agri_plan',      data.plan || 'freemium');

  return data;
}

// ─────────────────────────────────────────────
//  CONNEXION GOOGLE
// ─────────────────────────────────────────────

export async function fbLoginGoogle() {
  const provider = new GoogleAuthProvider();
  provider.addScope('profile');
  provider.addScope('email');

  const result = await signInWithPopup(auth, provider);
  const user   = result.user;
  const uid    = user.uid;

  let snap = await getDoc(doc(db, 'users', uid));

  if (!snap.exists()) {
    // Premier login → créer profil
    const phone    = user.phoneNumber || uid.slice(0, 10);
    const farmerId = makeFarmerId(phone);
    const profile  = {
      uid, farmerId,
      name: user.displayName,
      phone: user.phoneNumber || '',
      email: user.email,
      language: 'fr', crops: '',
      role: 'user', plan: 'freemium',
      walletBalance: 0, active: true,
      authProvider: 'google',
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp()
    };
    await setDoc(doc(db, 'users', uid), profile);
    await setDoc(doc(db, 'farmerIndex', farmerId), {
      uid, email: user.email, phone: user.phoneNumber || '', name: user.displayName, role: 'user'
    });
    snap = await getDoc(doc(db, 'users', uid));
  } else {
    await updateDoc(doc(db, 'users', uid), { lastLogin: serverTimestamp() });
  }

  const data = snap.data();
  sessionStorage.setItem('agri_uid',       uid);
  sessionStorage.setItem('agri_farmer_id', data.farmerId);
  sessionStorage.setItem('agri_name',      data.name);
  sessionStorage.setItem('agri_role',      data.role);
  sessionStorage.setItem('agri_plan',      data.plan || 'freemium');
  return data;
}

// ─────────────────────────────────────────────
//  DÉCONNEXION
// ─────────────────────────────────────────────

export async function fbLogout() {
  await fetch('/firebase-logout', { method: 'POST' });
  await signOut(auth);
  sessionStorage.clear();
  window.location.href = '/';
}

// ─────────────────────────────────────────────
//  RESET MOT DE PASSE
// ─────────────────────────────────────────────

export async function fbResetPassword(email) {
  await sendPasswordResetEmail(auth, email);
}

// ─────────────────────────────────────────────
//  OBSERVATEUR D'ÉTAT
// ─────────────────────────────────────────────

export function fbWatchAuth(onUser, onNoUser) {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      const snap = await getDoc(doc(db, 'users', user.uid));
      snap.exists() ? onUser({ ...snap.data(), uid: user.uid }) : onNoUser();
    } else {
      onNoUser();
    }
  });
}

// ─────────────────────────────────────────────
//  API FIRESTORE  (données agriculteur)
// ─────────────────────────────────────────────

export const FS = {

  /* ── Profil ── */
  async getProfile(uid) {
    const s = await getDoc(doc(db, 'users', uid));
    return s.exists() ? s.data() : null;
  },
  async updateProfile(uid, data) {
    await updateDoc(doc(db, 'users', uid), { ...data, updatedAt: serverTimestamp() });
  },

  /* ── Parcelles ── */
  async addParcel(uid, parcel) {
    return addDoc(collection(db, 'users', uid, 'parcels'), { ...parcel, createdAt: serverTimestamp() });
  },
  async getParcels(uid) {
    const q = query(collection(db, 'users', uid, 'parcels'), orderBy('createdAt', 'desc'));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },

  /* ── Scans maladies ── */
  async saveScan(uid, scan) {
    return addDoc(collection(db, 'users', uid, 'scans'), { ...scan, scannedAt: serverTimestamp() });
  },
  async getScans(uid, n = 10) {
    const q = query(collection(db, 'users', uid, 'scans'), orderBy('scannedAt', 'desc'), limit(n));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },

  /* ── Wallet ── */
  async getBalance(uid) {
    const s = await getDoc(doc(db, 'users', uid));
    return s.exists() ? (s.data().walletBalance || 0) : 0;
  },
  async addTransaction(uid, { type, amount, description }) {
    await addDoc(collection(db, 'users', uid, 'transactions'), {
      type, amount, description, date: serverTimestamp()
    });
    const s = await getDoc(doc(db, 'users', uid));
    const current = s.data().walletBalance || 0;
    const newBal  = type === 'credit' ? current + amount : current - amount;
    await updateDoc(doc(db, 'users', uid), { walletBalance: newBal });
    return newBal;
  },
  async getTransactions(uid, n = 20) {
    const q = query(collection(db, 'users', uid, 'transactions'), orderBy('date', 'desc'), limit(n));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },

  /* ── Assurances ── */
  async getInsurances(uid) {
    const q = query(collection(db, 'insurances'), where('uid', '==', uid));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async addInsurance(uid, policy) {
    return addDoc(collection(db, 'insurances'), { uid, ...policy, status: 'active', createdAt: serverTimestamp() });
  },

  /* ── Documents FinPro ── */
  async saveFinDoc(uid, docData) {
    return addDoc(collection(db, 'users', uid, 'findocs'), { ...docData, generatedAt: serverTimestamp() });
  },
  async getFinDocs(uid) {
    const q = query(collection(db, 'users', uid, 'findocs'), orderBy('generatedAt', 'desc'));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },

  /* ── ADMIN ── */
  async getAllUsers(n = 200) {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(n));
    return (await getDocs(q)).docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async toggleUser(uid, active) {
    await updateDoc(doc(db, 'users', uid), { active });
  },
  async getUserStats() {
    const all = (await getDocs(collection(db, 'users'))).docs.map(d => d.data());
    return {
      total:   all.length,
      active:  all.filter(u => u.active).length,
      premium: all.filter(u => u.plan && u.plan !== 'freemium').length,
      byPlan:  all.reduce((a, u) => { a[u.plan || 'freemium'] = (a[u.plan || 'freemium'] || 0) + 1; return a; }, {})
    };
  }
};

export { auth, db };
