// ═══════════════════════════════════════════════════════════
//  AgriAssist Africa – Firebase Configuration
//  SDK v10 – ESM (type="module")
// ═══════════════════════════════════════════════════════════

import { initializeApp }        from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth }               from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore }          from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getAnalytics }          from "https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js";

const firebaseConfig = {
  apiKey:            "AIzaSyAgMTxkpKmJaV1u3eRSfLNsFRGKCwtaOVE",
  authDomain:        "agriassist-b7d6c.firebaseapp.com",
  projectId:         "agriassist-b7d6c",
  storageBucket:     "agriassist-b7d6c.firebasestorage.app",
  messagingSenderId: "1097024311616",
  appId:             "1:1097024311616:web:607738aa9496f385fd6aa5",
  measurementId:     "G-JYQYTQWNYY"
};

const app       = initializeApp(firebaseConfig);
export const auth      = getAuth(app);
export const db        = getFirestore(app);
export const analytics = getAnalytics(app);
export default app;
