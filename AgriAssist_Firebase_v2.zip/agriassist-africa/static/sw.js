const CACHE = 'agriassist-v1';
const STATIC = ['/', '/static/manifest.json', '/static/logo.jpg'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(STATIC).catch(() => {})));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request).then(r => {
      if (r && r.status === 200) { const c = r.clone(); caches.open(CACHE).then(cache => cache.put(e.request, c)); }
      return r;
    }).catch(() => caches.match(e.request).then(r => r || new Response('<h1>AgriAssist Africa — Mode Hors Ligne</h1>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } })))
  );
});
