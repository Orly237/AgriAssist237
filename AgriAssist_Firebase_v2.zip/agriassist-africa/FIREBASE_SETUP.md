# 🔥 Firebase – Guide de configuration AgriAssist Africa

## Projet Firebase
| Paramètre | Valeur |
|-----------|--------|
| Project ID | `agriassist-b7d6c` |
| Auth Domain | `agriassist-b7d6c.firebaseapp.com` |
| Firestore | Base principale |
| Analytics | G-JYQYTQWNYY |

---

## ✅ Étape 1 — Activer Firebase Authentication

1. Ouvrez https://console.firebase.google.com/project/agriassist-b7d6c/authentication
2. Cliquez **Commencer**
3. Activez ces méthodes de connexion :

| Fournisseur | Action |
|-------------|--------|
| **Email/Mot de passe** | ✅ Activer |
| **Google** | ✅ Activer + ajouter votre domaine |
| **Téléphone** | ✅ Activer (USSD futur) |

4. Dans **Paramètres → Domaines autorisés**, ajoutez :
   - `localhost`
   - `votre-domaine.com`

---

## ✅ Étape 2 — Créer Firestore

1. Ouvrez https://console.firebase.google.com/project/agriassist-b7d6c/firestore
2. Cliquez **Créer une base de données**
3. Choisissez **Mode Production**
4. Région : `europe-west1` (Paris) ou `us-central1`

---

## ✅ Étape 3 — Déployer règles et indexes

```bash
# Installer Firebase CLI
npm install -g firebase-tools

# Connexion et sélection du projet
firebase login
firebase use agriassist-b7d6c

# Déployer
firebase deploy --only firestore:rules,firestore:indexes
```

---

## ✅ Étape 4 — Créer les comptes Administrateur

### Via Firebase Console → Authentication → Ajouter un utilisateur :

| Email | Mot de passe |
|-------|-------------|
| `admin@agriassist.app` | `AgriAdmin@2026!` |
| `superadmin@agriassist.app` | `SuperAdmin#2026` |

### Puis créer leur profil Firestore dans `users/{uid}` :
```json
{
  "farmerId": "ADMIN001",
  "name": "Administrateur Principal",
  "role": "admin",
  "plan": "enterprise",
  "active": true,
  "phone": "+237697380148",
  "email": "admin@agriassist.app"
}
```

Et dans `farmerIndex/ADMIN001` :
```json
{
  "uid": "<firebase-uid>",
  "email": "admin@agriassist.app",
  "phone": "+237697380148",
  "name": "Administrateur Principal",
  "role": "admin"
}
```

---

## 🏗️ Architecture Firestore

```
users/{uid}
  ├── farmerId, name, phone, email
  ├── role: "user" | "admin"
  ├── plan: "freemium" | "starter" | "pro" | "premium"
  ├── walletBalance: number
  ├── language, crops, active
  ├── createdAt, lastLogin
  │
  ├── parcels/{id}      → nom, culture, surface, coords, ndvi
  ├── scans/{id}        → disease, confidence, recommendation
  ├── transactions/{id} → type, amount, description, date
  └── findocs/{id}      → type, content, generatedAt

farmerIndex/{farmerId}
  └── uid, email, phone, name, role

insurances/{id}
  └── uid, parcelId, risk, coverage, status

marketPrices/{commodity}
  └── price, trend, market, country, updatedAt
```

---

## 🔐 Identifiants Admin définitifs

| ID Agriculteur | Mot de passe | Rôle |
|---|---|---|
| **ADMIN001** | **AgriAdmin@2026!** | Administrateur Principal |
| **ADMIN002** | **SuperAdmin#2026** | Super Administrateur |

**Connexion :** Utiliser l'ID agriculteur ou l'email sur `/login`

---

## 🚀 Démarrage local

```bash
cd agriassist-africa
pip install -r requirements.txt
python app.py
# → http://localhost:5000
```

---

© 2026 AgriAssist Africa · Bafoussam, Cameroun · AgriAssist@africa.com
